﻿// CombatComponent.cpp
#include "CombatComponent.h"
#include "ComboMoveData.h"
#include "CombatStateMachine.h"
#include "Engine/World.h" // Required for GetWorld()
#include "TimerManager.h" // Required for FTimerManager
#include "GameFramework/Character.h" // Required for ACharacter (if playing montage on character)
#include "Animation/AnimInstance.h" // Required for UAnimInstance (if playing montage on character)
#include "CombatInputBuffer.h" // Make sure this is included
#include "ComboScorer.h"     // Include the scorer

#define LOG_SCREEN(Text) \
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Yellow, Text)

#define LOG_SEQ(Fmt,Idx,Total) \
    UE_LOG(LogTemp, Log, TEXT("[Seq] " Fmt "  (%d/%d)"), *CurrentMove->MoveID.ToString(), Idx, Total)

UCombatComponent::UCombatComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    PrimaryComponentTick.TickGroup = TG_PrePhysics;
}

void UCombatComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
    
    // 更新状态机
    if (StateMachine)
    {
        StateMachine->UpdateState(DeltaTime);
    }
    
    // TODO: 更新状态机的输入状态
    // 这里需要从 PlayerController 或其他输入源获取输入信息
    // 示例（需要根据实际输入系统调整）:
    /*
    if (APlayerController* PC = Cast<APlayerController>(GetOwner()->GetInstigatorController()))
    {
        bool bJumpPressed = PC->IsInputKeyDown(EKeys::SpaceBar);
        bool bBlockPressed = PC->IsInputKeyDown(EKeys::RightMouseButton);
        bool bWindRunPressed = PC->IsInputKeyDown(EKeys::LeftShift);
        
        if (StateMachine)
        {
            StateMachine->SetInputPressed(bJumpPressed, bBlockPressed, bWindRunPressed);
            
            // 获取移动输入
            FVector MovementInput = PC->GetInputVectorKeyMapping();
            float MoveAxis = FMath::Clamp(MovementInput.Size(), 0.0f, 1.0f);
            
            // 获取地面检测（需要实际的地面检测逻辑）
            bool bOnFloor = true; // 临时值，需要实际实现
            bool bWallDetect = false; // 临时值，需要实际实现
            
            StateMachine->SetMovementState(MoveAxis, bOnFloor, bWallDetect);
        }
    }
    */
}

void UCombatComponent::BeginPlay()
{
    Super::BeginPlay();

    // 初始化状态机
    if (!StateMachine)
    {
        StateMachine = NewObject<UCombatStateMachine>(this, TEXT("CombatStateMachine"));
    }

    // TODO: Load UComboMoveData assets into LoadedMovesForSim for the simulation
    // This would typically involve using AssetRegistry or direct TSoftObjectPtr loading.
    // For now, this will be empty, and you'll need to populate it with your A1-A5, B1-B3 assets.
    // Example (pseudo-code, actual loading depends on how you store/reference these assets):
    // LoadedMovesForSim.Add(TEXT("A1"), LoadObject<UComboMoveData>(nullptr, TEXT("/Game/Path/To/Your/DA_A1.DA_A1")));
    // LoadedMovesForSim.Add(TEXT("A2"), LoadObject<UComboMoveData>(nullptr, TEXT("/Game/Path/To/Your/DA_A2.DA_A2")));
    // ... and so on for all moves A1-A5, B1-B3
}

void UCombatComponent::AttemptCombo(const UComboMoveData* MoveData)
{
    // This function seems to be for directly attempting a known move.
    // The scoring logic would typically be used when trying to determine *which* move to execute
    // from a set of possible moves based on current input buffer.
    // For now, let's assume this function is called *after* a move has been selected (possibly via scoring).

    if(!MoveData || (StateMachine && !MoveData->ValidStates.Contains(StateMachine->GetCurrentState())))
    {
        return; // Invalid move or state
    }
    
    // if(CurrentMove) // Original logic for interrupting or queuing, can be kept or adapted
    // {
    //     // ... Handle existing move ...
    // }
    
    ExecuteMove(MoveData);
}

// Example of how scoring might be integrated when selecting a move from multiple candidates
// This is a conceptual function and would need to be called from your input handling logic.
const UComboMoveData* UCombatComponent::SelectBestMoveFromBuffer(const UCombatInputBuffer* InputBufferComponent)
{
    if (!InputBufferComponent || !GetOwner())
    {
        return nullptr;
    }

    const UComboMoveData* BestMove = nullptr;
    float HighestScore = -1.0f;

    // Iterate over all known moves in MoveTable
    for (const auto& Pair : MoveTable)
    {
        const UComboMoveData* CandidateMove = Pair.Value;
        if (!CandidateMove || (StateMachine && !CandidateMove->ValidStates.Contains(StateMachine->GetCurrentState())))
        {
            continue; // Skip invalid or non-executable moves
        }        // Use the new function in InputBuffer to find if the pattern matches and where
        // For simplicity, FlexBits is 0 here, but could be dynamic based on MoveData.
        int32 FlexBitsUsed = 0;
        int32 MatchStartIndex = InputBufferComponent->FindBestMatchStartIndex(CandidateMove, 0 /* FlexBits */, &FlexBitsUsed);

        if (MatchStartIndex != -1) // A match was found
        {
            UComboScorer* ScorerToUse = nullptr;
            if (CandidateMove->CustomScorerClass)
            {
                // TODO: Consider how Scorer instances are managed. 
                // Creating them on the fly might be inefficient.
                // They could be members of CombatComponent or cached.
                ScorerToUse = NewObject<UComboScorer>(this, CandidateMove->CustomScorerClass);
            }
            else
            {
                // Use a default scorer if none specified, or create a default instance here.
                // For this example, let's assume a default scorer instance is available or created.
                ScorerToUse = NewObject<UComboScorer>(this, UComboScorer::StaticClass()); 
            }            if (ScorerToUse)
            {
                FComboScoreContext Context;
                Context.InputBuffer = InputBufferComponent->GetGlobalBuffer(); // Copy the array to match value type
                Context.MoveData = CandidateMove;
                Context.BaseScore = CandidateMove->BaseScore;
                Context.MaxTimeWindow = 1.0f; // Example: 1 second max time window for pattern
                Context.MatchedPatternStartIndex = MatchStartIndex;
                Context.FlexBitsUsed = FlexBitsUsed;
                Context.PatternLength = CandidateMove->InputPattern.Num();

                float CurrentScore = ScorerToUse->CalculateScore(Context);

                if (CurrentScore > HighestScore)
                {
                    HighestScore = CurrentScore;
                    BestMove = CandidateMove;
                }
            }
        }
    }

    if (BestMove)
    {
        LOG_SCREEN(FString::Printf(TEXT("Best Move Selected: %s with Score: %f"), *BestMove->MoveID.ToString(), HighestScore));
    }
    else
    {
        LOG_SCREEN(TEXT("No matching move found or scored."));
    }
    
    return BestMove;
}

void UCombatComponent::ExecuteMove(const UComboMoveData* Move)
{
    CurrentMove = Move;
    ComboCounter = 0;
    
    // 动画播放
    if(Move->AttackMontage)
    {
        // PlayAnimMontage(Move->AttackMontage); // Original line
        ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
        if (OwnerCharacter && OwnerCharacter->GetMesh())
        {
            UAnimInstance* AnimInstance = OwnerCharacter->GetMesh()->GetAnimInstance();
            if (AnimInstance)
            {
                AnimInstance->Montage_Play(Move->AttackMontage);
            }
        }
    }
    
    // 设置连招窗口
    const float FrameTime = 1.0f / 60.0f;
    ComboWindowEnd = GetWorld()->GetTimeSeconds() + 
        (Move->StartupFrames + Move->ActiveFrames) * FrameTime;
}

void UCombatComponent::OnMoveCompleted()
{
    CurrentMove = nullptr;
    ComboCounter = 0;
}

// --- Simulation Functions ---

void UCombatComponent::StartSimulatingCombo(FName InitialMoveID)
{
    const UComboMoveData* InitialMove = LoadedMovesForSim.FindRef(InitialMoveID);
    if (InitialMove)
    {
        ExecuteSimulatedMove(InitialMove);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("StartSimulatingCombo: InitialMoveID '%s' not found in LoadedMovesForSim."), *InitialMoveID.ToString());
    }
}

void UCombatComponent::SimulateLightAttack()
{
    const UComboMoveData* NextMove = nullptr;
    if (!CurrentSimulatedMove) // Start a new combo if not already in one
    {
        // Assuming A1 is the default starting light attack for simulation
        NextMove = LoadedMovesForSim.FindRef(TEXT("A1")); 
    }
    else if (bIsInputWindowOpen && CurrentSimulatedMove->NextLightAttackMove_Sim)
    {
        NextMove = CurrentSimulatedMove->NextLightAttackMove_Sim;
    }

    if (NextMove)
    {
        ExecuteSimulatedMove(NextMove);
    }
    else if (CurrentSimulatedMove && bIsInputWindowOpen)
    {
        UE_LOG(LogTemp, Log, TEXT("SimulateLightAttack: No NextLightAttackMove_Sim defined for %s or input window closed."), *CurrentSimulatedMove->MoveID.ToString());
    }
    else if (!CurrentSimulatedMove)
    {
        UE_LOG(LogTemp, Log, TEXT("SimulateLightAttack: No current move and A1 not found."));
    }
}

void UCombatComponent::SimulateHeavyAttack()
{
    const UComboMoveData* NextMove = nullptr;
    if (CurrentSimulatedMove && bIsInputWindowOpen && CurrentSimulatedMove->NextHeavyAttackMove_Sim)
    {
        NextMove = CurrentSimulatedMove->NextHeavyAttackMove_Sim;
    }
    // Heavy attacks cannot start a combo in this simulation setup

    if (NextMove)
    {
        ExecuteSimulatedMove(NextMove);
    }
    else if (CurrentSimulatedMove && bIsInputWindowOpen)
    {
        UE_LOG(LogTemp, Log, TEXT("SimulateHeavyAttack: No NextHeavyAttackMove_Sim defined for %s or input window closed."), *CurrentSimulatedMove->MoveID.ToString());
    }
     else if (!CurrentSimulatedMove)
    {
        UE_LOG(LogTemp, Log, TEXT("SimulateHeavyAttack: Cannot start combo with heavy attack or no current move."));
    }
}

void UCombatComponent::ExecuteSimulatedMove(const UComboMoveData* MoveData)
{
    if (!MoveData || !GetWorld())
    {
        UE_LOG(LogTemp, Warning, TEXT("ExecuteSimulatedMove: Invalid MoveData or GetWorld() is null."));
        return;
    }

    CurrentSimulatedMove = MoveData;
    bIsInputWindowOpen = false; // Reset input window immediately

    // Clear any existing timers to prevent overlap
    GetWorld()->GetTimerManager().ClearTimer(MoveDurationTimer);
    GetWorld()->GetTimerManager().ClearTimer(InputWindowTimer_Open);
    GetWorld()->GetTimerManager().ClearTimer(InputWindowTimer_Close);

    FString LogMessage = FString::Printf(TEXT("SIM: Executing Move: %s"), *MoveData->MoveID.ToString());
    UE_LOG(LogTemp, Log, TEXT("%s"), *LogMessage);
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 3.f, FColor::Green, LogMessage);
    }

    // Simulate move duration (3 seconds total)
    GetWorld()->GetTimerManager().SetTimer(MoveDurationTimer, this, &UCombatComponent::OnSimulatedMoveCompleted, 3.0f, false);

    // Input window opens after 1 second (at the start of the 2nd second) and lasts for 1 second
    GetWorld()->GetTimerManager().SetTimer(InputWindowTimer_Open, this, &UCombatComponent::OpenSimulatedInputWindow, 1.0f, false);
}

void UCombatComponent::OpenSimulatedInputWindow()
{
    if (!CurrentSimulatedMove || !GetWorld())
    {
        bIsInputWindowOpen = false; // Ensure it's closed if something is wrong
        return;
    }

    bIsInputWindowOpen = true;
    FString LogMessage = FString::Printf(TEXT("SIM: Input Window OPEN for: %s"), *CurrentSimulatedMove->MoveID.ToString());
    UE_LOG(LogTemp, Log, TEXT("%s"), *LogMessage);
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Yellow, LogMessage);
    }

    // Input window closes after 1 second (total 2 seconds into the move)
    GetWorld()->GetTimerManager().SetTimer(InputWindowTimer_Close, this, &UCombatComponent::CloseSimulatedInputWindow, 1.0f, false);
}

void UCombatComponent::CloseSimulatedInputWindow()
{
    bIsInputWindowOpen = false;
    if (CurrentSimulatedMove) // Check if move is still valid
    {
        FString LogMessage = FString::Printf(TEXT("SIM: Input Window CLOSED for: %s"), *CurrentSimulatedMove->MoveID.ToString());
        UE_LOG(LogTemp, Log, TEXT("%s"), *LogMessage);
        if (GEngine)
        {
            GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Red, LogMessage);
        }
    }
}

void UCombatComponent::OnSimulatedMoveCompleted()
{
    if (CurrentSimulatedMove)
    {
        FString LogMessage = FString::Printf(TEXT("SIM: Move COMPLETED: %s"), *CurrentSimulatedMove->MoveID.ToString());
        UE_LOG(LogTemp, Log, TEXT("%s"), *LogMessage);
        if (GEngine)
        {
            GEngine->AddOnScreenDebugMessage(-1, 3.f, FColor::Cyan, LogMessage);
        }
    }
    
    CurrentSimulatedMove = nullptr;
    bIsInputWindowOpen = false; // Ensure window is closed

    // It's good practice to clear timers that are meant to be one-shot or when their context is gone
    GetWorld()->GetTimerManager().ClearTimer(MoveDurationTimer);
    GetWorld()->GetTimerManager().ClearTimer(InputWindowTimer_Open);
    GetWorld()->GetTimerManager().ClearTimer(InputWindowTimer_Close);
}

TArray<const UComboMoveData*> UCombatComponent::GetAllMoves() const
{
	TArray<const UComboMoveData*> AllMoves;
	for (const auto& Pair : MoveTable)
	{
		if (Pair.Value)
		{
			AllMoves.Add(Pair.Value);
		}
	}
	return AllMoves;
}

void UCombatComponent::InitMoveTable(const TMap<FName, const UComboMoveData*>& InTable)
{
	MoveTable.Empty();
	for (const auto& Pair : InTable)
	{
		MoveTable.Add(Pair.Key, Pair.Value);
	}
}

TArray<UComboMoveData*> UCombatComponent::GetAllMovesForBlueprint() const
{
	TArray<UComboMoveData*> AllMoves;
	for (const auto& Pair : MoveTable)
	{
		if (Pair.Value)
		{
			// Cast away const for Blueprint compatibility
			AllMoves.Add(const_cast<UComboMoveData*>(Pair.Value));
		}
	}
	return AllMoves;
}