#include "ComboScorer.h"
#include "CombatInputBuffer.h" // For FCombatInputEntry
#include "ComboMoveData.h"     // For UComboMoveData

// Default implementation for CalculateScore
// Score = Base + OrderBonus – Δt Penalty + FlexBonus
float UComboScorer::CalculateScore_Implementation(const FComboScoreContext& Context) const
{
    if (Context.InputBuffer.Num() == 0 || !Context.MoveData || Context.MatchedPatternStartIndex < 0)
    {
        return 0.0f; // Invalid context
    }

    float Score = Context.BaseScore;    // --- OrderBonus (Example: bonus if matched earlier in buffer) ---
    // This is a simple example; a more complex logic might be needed.
    // Lower MatchedPatternStartIndex means it was found earlier in the buffer.
    // We want to give a higher bonus for earlier matches.
    // Give bonus for patterns that match at the END of the buffer (most recent inputs)
    if (Context.InputBuffer.Num() > 0) {
        // 如果模式在缓冲区末尾匹配（最新输入），给予更高分数
        int32 EndPosition = Context.MatchedPatternStartIndex + Context.MoveData->InputPattern.Num();
        if (EndPosition == Context.InputBuffer.Num()) {
            Score += 50.0f; // 匹配最新输入时的奖励分数
        } else {
            // 距离末尾越远，分数越低
            Score -= (Context.InputBuffer.Num() - EndPosition) * 5.0f;
        }
    }

    // --- Δt Penalty (Time Penalty) ---
    // Penalty based on how long the input sequence took compared to a max window.
    // This requires timestamps in FCombatInputEntry and the pattern length from MoveData.
    if (Context.MoveData->InputPattern.Num() > 0 && Context.MatchedPatternStartIndex + Context.MoveData->InputPattern.Num() <= Context.InputBuffer.Num())
    {
        const float FirstInputTime = Context.InputBuffer[Context.MatchedPatternStartIndex].Timestamp;
        const float LastInputTime = Context.InputBuffer[Context.MatchedPatternStartIndex + Context.MoveData->InputPattern.Num() - 1].Timestamp;
        const float TimeTaken = LastInputTime - FirstInputTime;
        
        if (TimeTaken > Context.MaxTimeWindow)
        {
            // Apply penalty if time taken exceeds the allowed window
            Score -= (TimeTaken - Context.MaxTimeWindow) * 50.0f; // Example: 50 points penalty per second over limit
        }
        else
        {
            // Optional: Bonus for faster execution within the window
            Score += (Context.MaxTimeWindow - TimeTaken) * 20.0f; // Example: 20 points bonus per second faster
        }
    }    // --- FlexBonus (bonus for using flexible inputs) ---
    if (Context.FlexBitsUsed > 0)
    {
        // Count the number of bits set in FlexBitsUsed
        int32 FlexInputCount = 0;
        int32 TempFlexBits = Context.FlexBitsUsed;
        while (TempFlexBits > 0)
        {
            if (TempFlexBits & 1) FlexInputCount++;
            TempFlexBits >>= 1;
        }
        Score += FlexInputCount * 5.0f; // 5 points bonus per flexible input used
    }

    return FMath::Max(0.0f, Score); // Ensure score is not negative
}
