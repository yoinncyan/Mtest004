// CombatInputBuffer.cpp
#include "CombatInputBuffer.h"
#include "ComboScorer.h" // Include the new Scorer header
#include "ComboMoveData.h" // Ensure UComboMoveData type is available

// Constructor Definition
UCombatInputBuffer::UCombatInputBuffer()
    : bInChainWindow(false)
    , bUseChainBuffer(false)
    , CurrentFlexMask(0)
    , LastInputTime(0.0f)
{
    PrimaryComponentTick.bCanEverTick = false; // Typically, input buffers don't need to tick themselves
}

void UCombatInputBuffer::ProcessInput(ECombatInputKey Key, const FVector2D& StickInput)
{
    const float CurrentTime = GetWorld()->GetTimeSeconds();
    
    FCombatInputEntry NewEntry;
    NewEntry.Key = Key;
    NewEntry.Direction = StickInput;
    NewEntry.Timestamp = CurrentTime;
    
    // 全局缓冲管理
    if(GlobalBuffer.Num() >= GLOBAL_BUFFER_SIZE) GlobalBuffer.RemoveAt(0);
    GlobalBuffer.Add(NewEntry);
    
    // 链式缓冲特殊处理
    if(bInChainWindow && ChainBuffer.Num() < CHAIN_BUFFER_SIZE)
    {
        ChainBuffer.Add(NewEntry);
    }
    
    LastInputTime = CurrentTime;
}

// Modified MatchPattern to support returning score or detailed match info
// For simplicity, we'll keep MatchPattern for boolean checks, 
// and add a new function or modify CombatComponent to handle scoring.

bool UCombatInputBuffer::MatchPattern(const TArray<ECombatInputKey>& Pattern, int32 FlexBits) const
{
    const auto& BufferToUse = bUseChainBuffer ? ChainBuffer : GlobalBuffer;
    
    if (Pattern.Num() == 0 || BufferToUse.Num() < Pattern.Num())
    {
        return false;
    }

    // Sliding window matching algorithm
    for(int32 StartIdx = 0; StartIdx <= BufferToUse.Num() - Pattern.Num(); ++StartIdx)
    {
        bool bCurrentMatch = true;
        for(int32 i = 0; i < Pattern.Num(); ++i)
        {
            const FCombatInputEntry& Entry = BufferToUse[StartIdx + i];
            const ECombatInputKey TargetKey = Pattern[i];
            
            // Check if the key matches or if it's a flexible input allowed by FlexBits
            if(Entry.Key != TargetKey && !(FlexBits & (1 << i)))
            {
                bCurrentMatch = false;
                break;
            }
        }
        if(bCurrentMatch) return true; // Found a match
    }
    return false; // No match found
}

// New function to find the best match and return its score context details
// Returns the start index of the best match in the buffer, or -1 if no match.
int32 UCombatInputBuffer::FindBestMatchStartIndex(const UComboMoveData* MoveData, int32 FlexBits, int32* OutFlexBitsUsed) const
{
    if (!MoveData || MoveData->InputPattern.Num() == 0) return -1;

    const auto& BufferToUse = bUseChainBuffer ? ChainBuffer : GlobalBuffer;
    const TArray<ECombatInputKey>& Pattern = MoveData->InputPattern;

    if (BufferToUse.Num() < Pattern.Num()) return -1;

    int32 BestMatchStartIndex = -1;
    int32 BestFlexBitsUsed = 0;
    
    // Find the best match (for now, just the first one, but could be enhanced with scoring)
    for (int32 StartIdx = 0; StartIdx <= BufferToUse.Num() - Pattern.Num(); ++StartIdx)
    {
        bool bCurrentMatch = true;
        int32 CurrentFlexBitsUsed = 0;
        
        for (int32 i = 0; i < Pattern.Num(); ++i)
        {
            const FCombatInputEntry& Entry = BufferToUse[StartIdx + i];
            const ECombatInputKey TargetKey = Pattern[i];
            
            if (Entry.Key != TargetKey)
            {
                // Check if this position allows flexible input
                if (FlexBits & (1 << i))
                {
                    CurrentFlexBitsUsed |= (1 << i); // Mark this flex bit as used
                }
                else
                {
                    bCurrentMatch = false;
                    break;
                }
            }
        }
        
        if (bCurrentMatch)
        {
            BestMatchStartIndex = StartIdx;
            BestFlexBitsUsed = CurrentFlexBitsUsed;
            break; // For now, just return the first match. Could be enhanced to find the "best" match.
        }
    }
    
    // Set the output parameter if provided
    if (OutFlexBitsUsed)
    {
        *OutFlexBitsUsed = BestFlexBitsUsed;
    }
    
    return BestMatchStartIndex;
}

void UCombatInputBuffer::AddInput(ECombatInputKey Key)
{
    ProcessInput(Key, FVector2D::ZeroVector);
}

void UCombatInputBuffer::ClearBuffer()
{
    GlobalBuffer.Empty();
    ChainBuffer.Empty();
}

void UCombatInputBuffer::RemoveOldestInput()
{
    if (GlobalBuffer.Num() > 0)
    {
        GlobalBuffer.RemoveAt(0);
    }
}

TArray<ECombatInputKey> UCombatInputBuffer::GetCurrentInputs() const
{
    TArray<ECombatInputKey> CurrentInputs;
    for (const FCombatInputEntry& Entry : GlobalBuffer)
    {
        CurrentInputs.Add(Entry.Key);
    }
    return CurrentInputs;
}
