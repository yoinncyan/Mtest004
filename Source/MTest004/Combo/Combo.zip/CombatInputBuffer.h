﻿// CombatInputBuffer.h
#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CombatInputBuffer.generated.h"

UENUM(BlueprintType)
enum class ECombatInputKey : uint8
{
    CIK_Light,
    CIK_Heavy,
    CIK_Jump,
    CIK_Block,
    CIK_MAX
};

USTRUCT(BlueprintType)
struct FCombatInputEntry
{
    GENERATED_BODY()
    
    UPROPERTY(VisibleAnywhere)
    ECombatInputKey Key;
    
    UPROPERTY(VisibleAnywhere)
    FVector2D Direction;
    
    UPROPERTY(VisibleAnywhere)
    float Timestamp;
};

UCLASS(ClassGroup=(Combat), meta=(BlueprintSpawnableComponent))
class MTEST004_API UCombatInputBuffer : public UActorComponent
{
    GENERATED_BODY()
public:
    UCombatInputBuffer(); // Constructor declaration

    static constexpr int32 GLOBAL_BUFFER_SIZE = 6; // 6逻辑帧存储
    static constexpr int32 CHAIN_BUFFER_SIZE = 2;
    void ProcessInput(ECombatInputKey Key, const FVector2D& StickInput);
    bool MatchPattern(const TArray<ECombatInputKey>& Pattern, int32 FlexBits) const;
    int32 FindBestMatchStartIndex(const class UComboMoveData* MoveData, int32 FlexBits, int32* OutFlexBitsUsed = nullptr) const;    // Getter for accessing the buffer from external components
    UFUNCTION(BlueprintPure, Category = "Input")
    const TArray<FCombatInputEntry>& GetGlobalBuffer() const { return GlobalBuffer; }

    UFUNCTION(BlueprintPure, Category = "Input")
    const TArray<FCombatInputEntry>& GetChainBuffer() const { return ChainBuffer; }

    // Additional utility functions
    UFUNCTION(BlueprintCallable, Category = "Input")
    void AddInput(ECombatInputKey Key);

    UFUNCTION(BlueprintCallable, Category = "Input")
    void ClearBuffer();

    UFUNCTION(BlueprintCallable, Category = "Input")
    void RemoveOldestInput();

    UFUNCTION(BlueprintPure, Category = "Input")
    TArray<ECombatInputKey> GetCurrentInputs() const;

protected:
    TArray<FCombatInputEntry> GlobalBuffer;
    TArray<FCombatInputEntry> ChainBuffer;

    bool bInChainWindow = false;    // Added
    bool bUseChainBuffer = false;   // Added
    
    uint8 CurrentFlexMask = 0;
    float LastInputTime = 0.0f;
};
