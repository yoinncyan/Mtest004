﻿// CombatComponent.h
#pragma once
#include "CoreMinimal.h"
#include "ComboMoveData.h"
#include "Components/ActorComponent.h"
#include "ComboMoveData.h"
#include "CombatComponent.generated.h"

class UCombatStateMachine; // Forward declaration
class UCombatInputBuffer; // Forward declaration

/** 逻辑按键——轻 / 重 */
UENUM(BlueprintType)
enum class ECombatKey : uint8 { Light, Heavy };

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class MTEST004_API UCombatComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UCombatComponent();    /************** ① 公开接口 **************/
    void InitMoveTable(const TMap<FName, const UComboMoveData*>& InTable);
    void HandleInputKey(ECombatKey Key);    // Scoring and selection functions
    UFUNCTION(BlueprintCallable, Category = "Combat")    const UComboMoveData* SelectBestMoveFromBuffer(const UCombatInputBuffer* InputBufferComponent);

    // Get all available moves (C++ version with const pointers)
    TArray<const UComboMoveData*> GetAllMoves() const;

    // Get all available moves (Blueprint version with non-const pointers)
    UFUNCTION(BlueprintCallable, Category = "Combat")
    TArray<UComboMoveData*> GetAllMovesForBlueprint() const;/************** ② 内部状态 **************/
/** 招式表：MoveID -> DataAsset */
    TMap<FName, const UComboMoveData*> MoveTable;

    /** 当前正在播放的模拟招式 */
    //UPROPERTY()
    //TObjectPtr<UComboMoveData> CurrentMove = nullptr;

    /** 输入缓冲 */
    UPROPERTY()
    TArray<ECombatKey> InputBuffer;

    bool bWindowOpen = false;
    FTimerHandle WindowTimer;
    FTimerHandle EndTimer;

    /************** ③ 内部函数 **************/
    void TryConsumeBufferAndGotoNext(ECombatKey Key);
    void ExecuteSimulatedMove(UComboMoveData* Move);
    void OpenInputWindow();
    void CloseMove();

    int32 SeqIndex = 0;                 // 已匹配到的步数（从 0 开始）
    TArray<TSoftObjectPtr<UComboMoveData>> TargetSequence; // 运行期按资产长度动态分配
    bool bPrereqReady = false;
    TArray<FName> TargetSeqIDs;           // 只存 MoveID

    /* 可缓存 C 指针，避免重复查表 */
    const UComboMoveData* CachedSpecialMove = nullptr;
    TArray<FName> TargetSequenceMoveID;   // 只存 MoveID
    FName CurrentID;                // 记录当前 MoveID

public:    
    void AttemptCombo(const UComboMoveData* MoveData);

    // Simulation Functions
    void SimulateLightAttack();
    void SimulateHeavyAttack();
    void StartSimulatingCombo(FName InitialMoveID);
    
protected:
    TMap<FName, const UComboMoveData*> LoadedMoves;

    TMap<FName, const UComboMoveData*> LoadedMovesForSim; // For simulation
    
    // 不要用UPROPERTY修饰const指针，否则会导致反射和赋值出错
    const UComboMoveData* CurrentMove = nullptr;
    const UComboMoveData* CurrentSimulatedMove = nullptr; // For simulation

    UPROPERTY()
    UCombatStateMachine* StateMachine; // Added
    
    int32 ComboCounter = 0;
    float ComboWindowEnd = 0.0f;

    // Simulation Timers and State
    FTimerHandle MoveDurationTimer;
    FTimerHandle InputWindowTimer_Open;
    FTimerHandle InputWindowTimer_Close;
    bool bIsInputWindowOpen = false;
    
    void ExecuteMove(const UComboMoveData* Move);
    void OnMoveCompleted();

    // Simulation Helper Functions
    void ExecuteSimulatedMove(const UComboMoveData* MoveData);
    void OpenSimulatedInputWindow();
    void CloseSimulatedInputWindow();
    void OnSimulatedMoveCompleted();

    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
};
